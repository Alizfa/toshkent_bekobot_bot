const { Sequelize } = require("sequelize");

const sequelize = new Sequelize("telegram_bot", "postgres", "123456", {
  host: "localhost",
  dialect: "postgres",
});

module.exports = sequelize;
