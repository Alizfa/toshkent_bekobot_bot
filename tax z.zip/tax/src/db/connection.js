const setupModels = require("./association.js");
const sequelize = require("./seuqelize.js");

async function dbConnection() {
  try {
    await sequelize.authenticate();
    console.log("DB ga ulandi");

    await setupModels();

    // await sequelize.sync({ force: true });

    await sequelize.sync();
    console.log("Bazaga sinxron boldi");
  } catch (error) {
    console.log("Xato DB bilan boglanishda", error);
  }
}

module.exports = { dbConnection };
