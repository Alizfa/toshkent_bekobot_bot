const UserModel = require("../user/user.model.js");

function setupModels() {}

module.exports = setupModels;
