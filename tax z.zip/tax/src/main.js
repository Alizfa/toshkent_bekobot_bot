const { dbConnection } = require("./db/connection.js");
const botController = require("./controller.js");
process.on("uncaughtException", (error) => {
  console.log("uncaughtException", error);
});
process.on("unhandledRejection", (promise, reason) => {
  console.log("unhandledRejection", promise, "reason:", reason);
});
async function runBot() {
  await dbConnection();
  botController();
}

runBot();

// const ixtiyoriy = Math.round(Math.random() * 10);

// switch (ixtiyoriy) {
//   case 1:
//     console.log("bir");
//     break;
//   case 2:
//     console.log("ikki");
//     break;
//   case 3:
//     console.log("uch");
//     break;
//   default:
//     console.log("boshqa", ixtiyoriy);
// }
