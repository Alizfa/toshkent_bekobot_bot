const fs = require("fs/promises");

let usersStates = {};
let userData = {};

async function getTaxiGroupChatId() {
  try {
    const chatIdJSON = await fs.readFile("./getTaxiGroupChatId.json", "utf8");
    const { chat_id } = JSON.parse(chatIdJSON);
    return chat_id;
  } catch (error) {
    console.log("error getTaxiGroupChatId");
    return -4589152590;
  }
}
async function getTaxiGroupChatId() {
  try {
    const chatIdJSON = await fs.readFile("./getTaxiGroupChatId.json", "utf8");
    const { chat_id } = JSON.parse(chatIdJSON);
    return chat_id;
  } catch (error) {
    console.log("error getTaxiGroupChatId");
    return -4589152590;
  }
}
async function writeChatId(chat_id) {
  return fs.writeFile("./getTaxiGroupChatId.json", JSON.stringify({ chat_id }));
}
// getTaxiGroupChatId();
// "-4589152590";
// const mainGroupChatId = "-1002308286860";

module.exports = {
  usersStates,
  userData,
  getTaxiGroupChatId,
  writeChatId,
  // taxiGroupChatId,
  // mainGroupChatId,
};
//taxizakazguruhimaxfiy
