const TelegramBot = require("node-telegram-bot-api");

const token = "7929925993:AAHRR2h3OUwV22kpPZBhIPgwLG2LH869AtQ";

const bot = new TelegramBot(token, { polling: true });

module.exports = bot;

// sanjar admin 538902740
