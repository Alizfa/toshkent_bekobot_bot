const onCallbackQuery = require("./actions/callback_query.js");
// const onContact = require("./actions/contact.js");
const onMessage = require("./actions/message/index.js");
const bot = require("./bot.js");

function botController() {
  bot.on("message", onMessage);

  bot.on("callback_query", onCallbackQuery);
}

module.exports = botController;
