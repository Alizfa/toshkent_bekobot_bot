const { DataTypes, or } = require("sequelize");
const sequelize = require("../db/seuqelize.js");

const UserModel = sequelize.define("users", {
  chat_id: {
    type: DataTypes.BIGINT,
    unique: true,
  },

  phone: {
    type: DataTypes.STRING,
  },
  role: {
    type: DataTypes.STRING,
    values: ["driver", "passanger"],
  },
  action: {
    type: DataTypes.STRING,
  },
  order: {
    type: DataTypes.STRING,
  },
});

module.exports = UserModel;
