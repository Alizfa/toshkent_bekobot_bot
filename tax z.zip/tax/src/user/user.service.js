const UserModel = require("./user.model");

function getUser(chat_id) {
  return UserModel.findOne({ where: { chat_id } });
}
function createUser(newUser) {
  return UserModel.create(newUser);
}
function updateUser(chat_id, updatedUser) {
  return UserModel.update(updatedUser, { where: { chat_id } });
}
function createOrder(chat_id, updatedUser) {
  return UserModel.update(updatedUser, { where: { chat_id } });
}

module.exports = { getUser, createUser, updateUser, createOrder };
