// const { userData, usersStates } = require("../store/data.js");

// const onContact = (msg) => {
//   const chatId = msg.chat.id;
//   const contact = msg.contact;

//   usersStates[chatId] = "waiting_for_name";

//   userData[chatId] = {
//     phone: contact.phone_number,
//   };

//   // bot.sendMessage(chatId, "Iltimos, ismingizni kiriting:");
// };

// module.exports = onContact;
