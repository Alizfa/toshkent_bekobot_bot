const bot = require("../bot.js");
const onCallbackQuery = (callbackQuery) => {
  const chatId = callbackQuery.data.split("_")[2];
  const action = callbackQuery.data.split("_")[1];

  if (!userData[chatId]) {
    bot.sendMessage(
      callbackQuery.message.chat.id,
      "Buyurtmachi ma'lumotlari topilmadi."
    );
    return;
  }

  bot.answerCallbackQuery(callbackQuery.id, {
    text: "Buyurtma tasdiqlandi!",
    show_alert: false,
  });

  // bot.on("channel_post", (channelPost) => {
  //   const channelId = channelPost.chat.id;
  //   const channelMessage = channelPost.text;
  //   console.log(
  //     `Received a message in channel ${channelId}: ${channelMessage}`
  //   );
  //   bot.sendMessage(channelId, "salom", channelMessage);
  // });

  if (action === "accepted") {
    const driverProfile = "@driver_username";

    // bot.sendMessage(
    //   `Yangi buyurtma qabul qilindi.\nBuyurtmachi: ${userData[chatId].name}\nHaydovchi: ${driverProfile}`
    // );

    bot.sendMessage(chatId, "Sizning haydovchingiz: " + driverProfile);
  }
};

module.exports = onCallbackQuery;
