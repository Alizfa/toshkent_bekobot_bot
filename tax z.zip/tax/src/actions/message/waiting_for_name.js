const { usersStates, userData } = require("../../store/data.js");

function waiting_for_name(chatId, text) {
  userData[chatId].name = text;

  bot.sendMessage(
    chatId,
    `Rahmat ${text}, ma'lumotlaringiz qabul qilindi.
      Haydovchimisiz yoki yo'lovchi?`,
    {
      reply_markup: {
        keyboard: [["Haydovchi🚕", "Yo'lovchi🚶‍♂️"]],
        resize_keyboard: true,
        one_time_keyboard: true,
      },
    }
  );

  usersStates[chatId] = "waiting_for_driver_or_passenger";
}

module.exports = waiting_for_name;
