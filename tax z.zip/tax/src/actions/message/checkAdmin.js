// checkAdmin.js
const fs = require("fs");
const path = require("path");

// Admin ID'larni saqlovchi JSON faylini o'qish
const adminIdsPath = path.join(__dirname, "admin_id.json"); // Fayl yo'lini to'g'ri ko'rsatish
const adminIds = JSON.parse(fs.readFileSync(adminIdsPath)).admins;

// checkAdmin funksiyasi
const checkAdmin = (userId) => {
  console.log(`Tekshirilyapti: ${userId}`); // Tekshirish uchun log
  return adminIds.includes(userId.toString()); // ID'larni stringga aylantirish
};

module.exports = { checkAdmin };
