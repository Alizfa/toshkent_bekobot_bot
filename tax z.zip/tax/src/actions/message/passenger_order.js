const {
  taxiGroupChatId,
  userData,
  usersStates,
  getTaxiGroupChatId,
} = require("../../store/data.js");

async function passenger_order(chatId, text) {
  const userOrder = text;
  userData[chatId].order = userOrder;
  const taxiGroupChatId = await getTaxiGroupChatId();

  bot.sendMessage(
    taxiGroupChatId,
    `Yangi buyurtma: Ism: ${userData[chatId].name}
      Telefon: ${userData[chatId].phone}
      Zakaz: ${userOrder}`,
    {
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "Buyurtma tasdiqlandi",
              callback_data: `order_accepted_${chatId}`,
            },
          ],
        ],
      },
    }
  );

  bot.sendMessage(chatId, `Buyurtmangiz qabul qilindi: ${userOrder}`);

  usersStates[chatId] = null;
}

module.exports = passenger_order;
