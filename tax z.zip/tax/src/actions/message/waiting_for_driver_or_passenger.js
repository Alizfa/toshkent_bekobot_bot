const { usersStates } = require("../../store/data");

function waiting_for_driver_or_passenger(chatId, text) {
  if (text === "Haydovchi🚕") {
    bot.sendMessage(
      chatId,
      "VIP guruhga qoshilish uchun admin bilan bog'laning",
      {
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "Admin bilan bog'lanish",
                url: "https://t.me/Vip_taxi_admin",
              },
            ],
          ],
          resize_keyboard: true,
          one_time_keyboard: true,
        },
      }
    );
    usersStates[chatId] = "driver_menu";
  } else if (text === "Yo'lovchi🚶‍♂️") {
    bot.sendMessage(chatId, "Buyurtmangizni kiriting:", {
      reply_markup: {
        remove_keyboard: true,
      },
    });
    usersStates[chatId] = "passenger_order";
  } else {
    bot.sendMessage(
      chatId,
      "Iltimos, quyidagi variantlardan birini tanlang: Haydovchi yoki Yo'lovchi."
    );
  }
}

module.exports = waiting_for_driver_or_passenger;
