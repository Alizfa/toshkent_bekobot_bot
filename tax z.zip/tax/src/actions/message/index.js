const bot = require("../../bot.js");
const { getTaxiGroupChatId, writeChatId } = require("../../store/data.js");
const {
  getUser,
  createUser,
  updateUser,
} = require("../../user/user.service.js");
// const { taxiGroupChatId } = require("../../store/data.js");
const { checkAdmin } = require("./checkAdmin.js");
const fs = require("fs");

const keywords = JSON.parse(
  fs.readFileSync("./src/actions/message/keyword.json")
).keywords;

const containsKeyword = (text) => {
  return keywords.some((keyword) =>
    text?.toLowerCase().includes(keyword.toLowerCase())
  );
};

const askForPhone = (chatId) => {
  bot.sendMessage(
    chatId,
    `Telefon nomeringizni jo'nating 
    Отправьте свой номер телефона 
    ⬇️⬇️⬇️⬇️`,
    {
      reply_markup: {
        resize_keyboard: true,
        keyboard: [
          [
            {
              text: "Raqamni ulashish",
              request_contact: true,
            },
          ],
        ],
      },
    }
  );
};

const askRole = (chatId) => {
  bot.sendMessage(
    chatId,
    `Bosh menu 

    Haydovchimisiz yoki Yo'lovchi?`,
    {
      reply_markup: {
        keyboard: [[`Yo'lovchi🧍‍♂️`, `Haydovchi🚕`]],
        resize_keyboard: true,
      },
    }
  );
};

const askOrder = (chatId) => {
  bot.sendMessage(
    chatId,
    `Iltimos, o'z zakazingizni qoldiring 
    Nomer o'zingiznikini yuboring❌

    Пожалуйста, разместите заказ`
  );
};

const saveOrderAndNotifyGroup = async (chatId, user, msg) => {
  const text = msg.text;
  const username = msg.from.first_name;

  bot.sendMessage(
    chatId,
    `Sizning habaringiz qabul qilindi✅✅ 
Ваше сообщение было получено ✅✅`
  );
  const taxiGroupChatId = await getTaxiGroupChatId();
  bot.sendMessage(
    taxiGroupChatId,
    `${username}

Nomeri : ${user.phone}
Zakazi: ${text}`
  );
};

const driverMenu = (chatId) => {
  bot.sendMessage(
    chatId,
    `VIP guruhga qo'shilish uchun adminga murojaat qiling ⏬`,
    {
      reply_markup: {
        remove_keyboard: true,
        resize_keyboard: true,
        inline_keyboard: [
          [
            {
              text: "VIPga ulanish",
              url: "https://t.me/Vip_taxi_admin",
            },
          ],
        ],
      },
    }
  );
};

const onMessage = async (msg) => {
  // console.log("msg", msg);
  const chatId = msg.chat.id;
  const text = msg.text;
  const username = msg.from.username;
  const first_name = msg.from.first_name;
  const messageId = msg.message_id;
  const userId = msg.from.id;
  if (text === "mainzakazguruhimaxfiy") {
    await writeChatId(chatId);
  }
  if (msg.chat.type === "supergroup") {
    const isAdmin = checkAdmin(userId);
    console.log(`Foydalanuvchi ID: ${userId}, Adminmi: ${isAdmin}`);

    if (isAdmin) {
      return;
    } else {
      console.log(`Foydalanuvchi oddiy: ${userId}`);
    }
    console.log(msg.from.username);

    if (msg.from.username && containsKeyword(text)) {
      console.log("ishladi");
      console.log("chatId", chatId);
      await bot.sendMessage(
        chatId,
        `Xurmatli 
Klient 
Sizning zakasingiz shafyorlar guruhiga tushdi

Lichkangizda Ishonchlik shafyorlarimiz kutmoqda

Qulaylik uchun bot orqali zakas bering👇`,
        {
          reply_markup: {
            inline_keyboard: [
              [
                {
                  text: "Bot orqali zakaz qilish",
                  url: "https://t.me/toshkent_bekobad_bot",
                },
              ],
            ],
          },
        }
      );
      // console.log(msg.from.first_name);
      const taxiGroupChatId = await getTaxiGroupChatId();

      await bot.sendMessage(
        taxiGroupChatId,
        `${msg.from.first_name}dan zakaz keldi:

${msg.text}
        `,
        {
          reply_markup: {
            inline_keyboard: [
              [
                {
                  text: "ZAKAZCHI",
                  url: `https://t.me/${msg.from.username}`,
                },
              ],
            ],
          },
        }
      );

      await bot.deleteMessage(chatId, msg.message_id);

      // try {
      //   await bot.deleteMessage(chatId, messageId);
      //   console.log(`Xabar o'chirildi: ${messageId}`);
      // } catch (error) {
      //   console.error(`Xabarni o'chirishda xato: ${error}`);
      // }
      // return;
    } else if (!msg.from.username) {
      bot.sendMessage(
        chatId,
        `Hurmatli: ${first_name}
Iltimos siz bot orqali zakaz bering`,
        {
          reply_markup: {
            inline_keyboard: [
              [
                {
                  text: "Bot orqali zakaz qilish",
                  url: `https://t.me/toshkent_bekobad_bot`,
                },
              ],
            ],
            resize_keyboard: true,
          },
        }
      );
    }

    // await bot.deleteMessage(chatId, messageId);
    // console.log("ishladi");
  } else {
    const contact = msg.contact;

    let user = await getUser(chatId);
    if (!user) {
      user = await createUser({ chat_id: chatId });
    }

    if (text === "/start") {
      await updateUser(chatId, {
        action: "",
        role: "",
        phone: "",
        order: "",
      });
      return askForPhone(chatId);
    }

    if (!user.phone) {
      if (contact && contact.phone_number) {
        await updateUser(chatId, { phone: contact.phone_number, action: "" });
      } else if (/^\+?[0-9]{10,15}$/.test(text)) {
        await updateUser(chatId, { phone: text, action: "" });
      } else {
        await updateUser(chatId, { action: "ask_for_phone" });
        return askForPhone(chatId);
      }
    }

    if (!user.role) {
      if (text === "Haydovchi🚕" || text === "Yo'lovchi🧍‍♂️") {
        await updateUser(chatId, { role: text, action: "ask_for_order" });
        return text === "Yo'lovchi🧍‍♂️" ? askOrder(chatId) : driverMenu(chatId);
      } else {
        await updateUser(chatId, { action: "ask_for_role" });
        return askRole(chatId);
      }
    }

    if (user.role === "Haydovchi🚕" && text === "Yo'lovchi🧍‍♂️") {
      await updateUser(chatId, { role: text, action: "ask_for_role" });
      return askOrder(chatId);
    }

    if (user.role === "Yo'lovchi🧍‍♂️" && text === "Haydovchi🚕") {
      await updateUser(chatId, { role: text, action: "ask_for_role" });
      return driverMenu(chatId);
    }

    if (user.role === "Yo'lovchi🧍‍♂️") {
      console.log("user", msg);

      await updateUser(chatId, { order: text, action: "ask_for_order" });
      await saveOrderAndNotifyGroup(chatId, user, msg);
      return;
    }

    if (text === "Haydovchi🚕") {
      return driverMenu(chatId);
    }

    console.log("Noto'g'ri holat yoki noto'g'ri xabar keldi.");
  }
};

module.exports = onMessage;
