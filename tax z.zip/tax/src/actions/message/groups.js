// const bot = require("../../bot");
// const { mainGroupChatId, taxiGroupChatId } = require("../../store/data");

// const groupMessage = async (msg) => {
//   const chatId = msg.chat.Id;
//   const messageId = msg.message_id;

//   if (chatId.toSting() === mainGroupChatId) {
//     try {
//       await bot.sendMessage(taxiGroupChatId, msg.text);

//       await bot.deleteMessage(mainGroupChatId, messageId.toSting());
//     } catch (error) {
//       console.error("Xatolik yuz berdi", error);
//     }
//   }
// };

// module.exports = { groupMessage };
