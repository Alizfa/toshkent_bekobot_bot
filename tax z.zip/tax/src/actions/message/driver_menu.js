const bot = require("../../bot.js");
const { usersStates } = require("../../store/data.js");

function driver_menu(chatId, text) {
  if (text === "Bosh sahifa") {
    bot.sendMessage(
      chatId,
      "Bosh sahifaga qaytish uchun /start buyrug'ini yuboring."
    );
    delete usersStates[chatId];
  } else {
    bot.sendMessage(chatId, "Iltimos, 'Bosh sahifa' ni tanlang.");
  }
}

module.exports = driver_menu;
