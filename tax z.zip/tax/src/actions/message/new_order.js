const bot = require("../../bot.js");

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data === "new_order") {
    // Here you can call your saveOrderAndNotifyGroup or newOrder functions
    await saveOrderAndNotifyGroup(chatId, user, query.message);
    // Optionally, you can send a response to the callback query
    bot.answerCallbackQuery(query.id, { text: "Buyurtmangiz qabul qilindi!" });
  }
});
